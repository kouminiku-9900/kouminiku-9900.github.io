Review audio fixtures — generated 2026-10-01

Two synthesized tones, mono PCM WAV, 16 kHz / 16 bit, 8 and 12 seconds.
They contain no samples, recordings, music artwork, or third-party content.
Freely usable for testing and review screenshots.

Extract this ZIP in iOS Files. In Five Disc Changer, choose an empty disc
slot and load these audio files or their folder. Keep the original files
in place; the app stores references. No Apple Music account is needed
for the file playback path.
